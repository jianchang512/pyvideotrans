# videotrans/util/tools.py
# 移除懒加载，避免某些环境下出错

from .help_role import *
from .help_ffmpeg import *
from .help_srt import *
from .help_misc import *
from .help_down import *

