# -*- coding: utf-8 -*-

VERSION = "v3.96"
VERSION_NUM = 120396
