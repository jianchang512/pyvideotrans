from videotrans.component.set_form import BaiduForm, \
    ChatgptForm, DeepLForm, DeepLXForm, TencentForm, ElevenlabsForm, InfoForm, AzureForm, GeminiForm, SetLineRole, \
    YoutubeForm, OttForm,CloneForm,SeparateForm,TtsapiForm,GPTSoVITSForm,TransapiForm,ArticleForm

__all__ = [
    "BaiduForm",
    "ChatgptForm",
    "DeepLForm",
    "DeepLXForm",
    "TencentForm",
    "ElevenlabsForm",
    "InfoForm", "AzureForm", "GeminiForm", "SetLineRole", "ElevenlabsForm", "YoutubeForm","OttForm","CloneForm","SeparateForm","TtsapiForm","TransapiForm","ArticleForm"
]
