# -*- coding: utf-8 -*-

VERSION="v1.51  pyvideotrans.com"
VERSION_NUM=11051